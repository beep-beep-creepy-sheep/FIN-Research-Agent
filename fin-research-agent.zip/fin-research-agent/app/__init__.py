"""Financial research agent package."""
